package br.com.hospital.hpem.model_entities;

public class Medico {

    private Long id;
    private String nomedomedico;
    private String especialidade;

}
