package br.com.hospital.hpem.controller;


public class PrimeiroEndPoint {

}
