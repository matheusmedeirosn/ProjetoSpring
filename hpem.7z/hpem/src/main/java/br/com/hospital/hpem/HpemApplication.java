package br.com.hospital.hpem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HpemApplication {

	public static void main(String[] args) {
		SpringApplication.run(HpemApplication.class, args);
	}

}
