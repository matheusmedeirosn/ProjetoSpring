package br.com.hospital.hpem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HpemApplicationTests {

	@Test
	void contextLoads() {
	}

}
